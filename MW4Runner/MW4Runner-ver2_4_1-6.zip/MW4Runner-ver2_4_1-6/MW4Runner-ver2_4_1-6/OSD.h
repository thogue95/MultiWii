
//OSD.h  
// OSD.cpp is used to send telemetry to the Walkera OSD Module on Port 0 at 5700 Baud

//#ifdef OSD_Telemetry


void sendTelemetry();
//void mixTable();
