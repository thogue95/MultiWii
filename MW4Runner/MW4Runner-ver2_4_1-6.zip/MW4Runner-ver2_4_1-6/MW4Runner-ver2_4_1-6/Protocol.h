#ifndef PROTOCOL_H_
#define PROTOCOL_H_

void serialCom();
void debugmsg_append_str(const char *str);
void WOSD_sendTelemetery();
static uint32_t swap32(uint32_t num);
static uint16_t swap16(uint16_t num);


#endif /* PROTOCOL_H_ */
