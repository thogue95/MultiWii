#include "Arduino.h"
#include "config.h"
#include "def.h"
#include "types.h"
#include "EEPROM.h"
#include "LCD.h"
#include "Output.h"
#include "GPS.h"
#include "MultiWii.h"
#include "Serial.h"
#include "Protocol.h"
#include "RX.h"

uint8_t MOSD_HEADER[] = {0x5A}; //header
uint8_t MOSD_AngY[] = {0x00, 0x01}; // confirmed
uint8_t MOSD_AngX[] = {0x00, 0x05};  //confirmed

uint8_t MOSD_5to10[] = {0x03, 0xCC, 0x00, 0xFF, 0xFF, 0xFF}; // 5, 6 bat voltage, 8-10 is flight height?
uint8_t MOSD_11to12[] = {0x00, 0x00}; //?
uint8_t MOSD_13to20[] = {0x8A, 0x8D, 0x39, 0x16, 0x81, 0x31, 0x49, 0xB7};  //GPS - confirmed
uint8_t MOSD_21[] = {0x02}; //ground speed
uint8_t MOSD_22[] = {0x02};//ground speed
uint8_t MOSD_23to26[] = {0x00, 0x00, 0x00, 0x00}; //alititude &speed?
uint8_t MOSD_27[] = {0x05}; //number of sats
uint8_t MOSD_28to29[] = {0xFF, 0xC3}; //compass - confirmed
uint8_t MOSD_30to32[] = {0x04, 0x7E, 0x02}; //?
//uint8_t MOSD_34[] = {0x40};
// the check sum is checksum8 modulo 256 Sum of Bytes % 256...checksum +=

//uint8_t OSD_Header = 0x5A; byte 0
//unint16_t OSD_AngY = 0; byte 1 & 2---
//unint16_t OSD_AngX = 0; byte 3 & 4
//uint16_t OSD_pMeterSum = 0;  //bytes 5 & 6...this could be vbat 2 is 1 byte
//uint32_t OSD_altitude = 0; //bytes 7-10
//uint16_t OSD_unkown1 = 0; //bytes 11 & 12
//uint32_t OSD_GpsLon = 0; //bytes 13-16 ...needs confimation 
//uint32_t OSD_GpsLat = 0; //bytes 17-20
//uint16_t OSD_GroundSpeed = 0; //bytes 21 & 22
//uint16_t OSD_DistFromHome = 0; //bytes 23 & 24
//uint16_t OSD_DirectionToHome = 0; //bytes 25 & 26
//uint8_t OSD_GpsSats = 0; // byte 27  --GPS_numSat
//uint16_t OSD_Compass = 0; //bytes 28 & 29
//uint16_t OSD_unknown2 = 0; //bytes 30 & 31
//uint8_t OSD_FlightMode = 0; byte 32

//f.GPS_FIX 1 byte

int filler= 0x00;
int toggle = 1;


void sendTelemetry() {

      SerialPrint(0,"OSD.cpp:  In sendTelemetry");



}

